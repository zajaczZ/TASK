$(function(){
    $("#gomb1").mouseenter(function () {
        $("#gomb1").text("Sikerült!"); 
    });
    $("#gomb1").mouseleave(function () {
        $("#gomb1").text("Húzd ide az egeret") 
        
    });


    $("#gomb2").click(function (e) { 
        e.preventDefault();
        const d = new Date();
        let hour = d.getHours();
        if(hour>=6 && hour<=12 ){
            alert("Jó reggelt!")
        }
        if(hour>12 && hour<=18)
        {
            alert("Jó napot!")

        }
        if(hour>18 && hour<=22)
        {
            alert("Jó estét!")

        }
    });
     $("#gomb3").click(function (e) { 
        e.preventDefault();
        const nev = $("#name").val()
        const email = $("#email").val()
        const szulev = $("#szulev").val()
        const beer = $("#beer").val()
        if(nev == "")
        {
            alert("Üres a név mező")
        }
        if(email == "")
        {
            alert("Üres az email mező")
        }
        if(szulev == "")
        {
            alert("Üres a születési év mező")
        }
        if(beer == "")
        {
            alert("Üres a kedvenc sör márkája mező")
        }
        const object={"Teljesnév":nev,"email-e":email,"Születési év":szulev,"Kedvenc sör márkája":beer}
        console.log(object)
        
     });



})